setwd("C:\\Users\\it24103210\\Desktop\\it24103210")


sum((1:15) %%3 ==0)


x<-c(1,2,3)
x[1] / x[2]^3 - 1 + 2 * x[3] - x[2 - 1]

#02
x <- 1:15
sum(x %% 3 == 0)

#03
x <- c(5, 9, 3, 12, 7, 12)
max_index <- 1
for (i in 2:length(x)) {
  if (x[i] > x[max_index]) {
    max_index <- i
  }
}
max_index

#04
x <- c(5, 9, 3, 12, 7, 12)
which.max(x)

